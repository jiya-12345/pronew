import Banner1 from "./banner1.jpeg";
import Banner2 from "./banner2.jpeg";
import Banner3 from "./banner3.jpeg";
import Banner4 from "./banner4.webp";
import Banner5 from "./banner5.webp";

export { Banner1, Banner2, Banner3, Banner4, Banner5 };